import React from "react";
import "./Home.css";

function Home() {
  return (
    <section id="home" className="home">
      <h1>Welcome to My Portfolio</h1>
      <p>I am a React.js Developer!</p>
    </section>
  );
}

export default Home;
